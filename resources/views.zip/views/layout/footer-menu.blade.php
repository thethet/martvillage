<div class="footer-menu">
				<div class="footer-content">
					<div class="menu-icon">
						<a href="">
							<img src="imgs/home-icon.png" alt="">
							Home
						</a>
					</div>

					<div class="menu-icon">
						<a href="">
							<img src="imgs/new-icon.png" alt="">
							New
						</a>
					</div>

					<div class="menu-icon">
						<a href="">
							<img src="imgs/edit-icon.png" alt="">
							Edit
						</a>
					</div>

					<div class="menu-icon">
						<a href="">
							<img src="imgs/reset.png" alt="">
							Reset
						</a>
					</div>

					<div class="menu-icon">
						<a href="">
							<img src="imgs/go-back.png" alt="">
							Back
						</a>
					</div>

					<div class="menu-icon">
						<a href="">
							<img src="imgs/toycon.png" alt="">
							Save&Exit
						</a>
					</div>
				</div>
			</div>

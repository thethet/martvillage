<div class="sidebar-menu">
	<div class="sidebar-menu-inner">
		<header class="logo-env">
			<!-- logo -->
			<div class="logo">
				<a href="{{ url("admin/dashboard") }}">
					@if(Auth::user()->company_id)
						<?php
							$companyLogo = App\Company::where('id', Auth::user()->company_id)->pluck('logo');
						?>
						@if($companyLogo[0])
							<img src="{{ asset('uploads/logos/' . $companyLogo[0]) }}" width="120" alt="" />
						@else
							<img src="{{ asset('assets/images/shwe-cargo.png') }}" width="120" alt="" />
						@endif
					@endif
				</a>
			</div>

			<!-- logo collapse icon -->
			<div class="sidebar-collapse">
				<a href="#" class="sidebar-collapse-icon"><!-- add class "with-animation" if you want sidebar to have animation during expanding/collapsing transition -->
					<i class="entypo-menu"></i>
				</a>
			</div>


			<!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
			<div class="sidebar-mobile-menu visible-xs">
				<a href="#" class="with-animation"><!-- add class "with-animation" to support animation -->
					<i class="entypo-menu"></i>
				</a>
			</div>

		</header>


		<ul id="main-menu" class="main-menu">
			<!-- add class "multiple-expanded" to allow multiple submenus to open -->
			<!-- class "auto-inherit-active-class" will automatically add "active" class for parent elements who are marked already with class "active" -->
			<li @if(Request::segment(1) == 'dashboard' || Request::segment(1) == null) class="active" @endif>
				<a href="{{ url("admin/dashboard") }}">
					<i class="entypo-gauge"></i>
					<span class="title">Dashboard</span>
				</a>
			</li>

			<li @if(Request::segment(1) == 'nric-codes' || Request::segment(1) == 'nric-townships' || Request::segment(1) == 'permissions' || Request::segment(1) == 'roles' || Request::segment(1) == 'companies' || Request::segment(1) == 'locations' || Request::segment(1) == 'countries' || Request::segment(1) == 'states' || Request::segment(1) == 'townships' || Request::segment(1) == 'pricing-setup' || Request::segment(1) == 'categories' || Request::segment(1) == 'currencies' || Request::segment(1) == 'prices' || Request::segment(1) == 'memberships') class="opened active has-sub" @else class="has-sub" @endif>
				<a href="{{ url('settings') }}">
					<i class="entypo-cog"></i>
					<span class="title">Settings</span>
				</a>
				<ul>
					@permission('nric-code-list')
						<li @if(Request::segment(1) == 'nric-codes') class="active" @endif>
							<a href="{{ url('/nric-codes') }}">
								<i class="entypo-vcard"></i>
								<span class="title">NRIC Code</span>
							</a>
						</li>
					@endpermission

					@permission('nric-township-list')
						<li @if(Request::segment(1) == 'nric-townships') class="active" @endif>
							<a href="{{ url('/nric-townships') }}">
								<i class="entypo-vcard"></i>
								<span class="title">NRIC Township</span>
							</a>
						</li>
					@endpermission

					@permission('permission-list')
						<li @if(Request::segment(1) == 'permissions') class="active" @endif>
							<a href="{{ url('/permissions') }}">
								<i class="entypo-lock"></i>
								<span class="title">Permission</span>
							</a>
						</li>
					@endpermission

					@permission('role-list')
						<li @if(Request::segment(1) == 'roles') class="active" @endif>
							<a href="{{ url('/roles') }}">
								<i class="entypo-flow-tree"></i>
								<span class="title">Role</span>
							</a>
						</li>
					@endpermission

					@permission('company-list')
						<li @if(Request::segment(1) == 'companies') class="active" @endif>
							<a href="{{ url('/companies') }}">
								<i class="entypo-suitcase"></i>
								<span class="title">Company</span>
							</a>
						</li>
					@endpermission

					<li @if(Request::segment(1) == 'locations' || Request::segment(1) == 'countries' || Request::segment(1) == 'states' || Request::segment(1) == 'townships') class="opened active has-sub" @else class="has-sub" @endif>
						<a href="{{ url('/locations') }}">
							<i class="entypo-location"></i>
							<span class="title">Location</span>
						</a>
						<ul>
							@permission('country-list')
								<li @if(Request::segment(1) == 'countries') class="active" @endif>
									<a href="{{ url('countries') }}">
										<i class="entypo-globe"></i>
										<span class="title">Country</span>
									</a>
								</li>
							@endpermission

							@permission('state-list')
								<li @if(Request::segment(1) == 'states') class="active" @endif>
									<a href="{{ url('states') }}">
										<i class="entypo-location"></i>
										<span class="title">State</span>
									</a>
								</li>
							@endpermission

							@permission('township-list')
								<li @if(Request::segment(1) == 'townships') class="active" @endif>
									<a href="{{ url('/townships') }}">
										<i class="entypo-direction"></i>
										<span class="title">Township</span>
									</a>
								</li>
							@endpermission
						</ul>
					</li>

					<li @if(Request::segment(1) == 'pricing-setup' || Request::segment(1) == 'categories' || Request::segment(1) == 'currencies' || Request::segment(1) == 'prices') class="opened active has-sub" @else class="has-sub" @endif>
						<a href="{{ url('pricing-setup') }}">
							<i class="fa fa-money"></i>
							<span class="title">Pricing Setup</span>
						</a>

						<ul>
							@permission('category-list')
								<li @if(Request::segment(1) == 'categories') class="active" @endif>
									<a href="{{ url('categories') }}">
										<i class="fa fa-balance-scale"></i>
										<span class="title">Category</span>
									</a>
								</li>
							@endpermission

							@permission('currency-list')
								<li @if(Request::segment(1) == 'currencies') class="active" @endif>
									<a href="{{ url('currencies') }}">
										<i class="fa fa-usd"></i>
										<span class="title">Currency</span>
									</a>
								</li>
							@endpermission

							@permission('price-list')
								<li @if(Request::segment(1) == 'prices') class="active" @endif>
									<a href="{{ url('/prices') }}">
										<i class="fa fa-money"></i>
										<span class="title">Price</span>
									</a>
								</li>
							@endpermission
						</ul>
					</li>

					@permission('membership-list')
						<li @if(Request::segment(1) == 'memberships') class="active" @endif>
							<a href="{{ url('/memberships') }}">
								<i class="entypo-tag"></i>
								<span class="title">Memberships</span>
							</a>
						</li>
					@endpermission
				</ul>
			</li>

			@permission('user-list')
				<li @if(Request::segment(1) == 'users') class="active" @endif>
					<a href="{{ url('/users') }}">
						<i class="entypo-users"></i>
						<span class="title">Users</span>
					</a>
				</li>
			@endpermission

			@permission('member-list')
				<li @if(Request::segment(1) == 'members') class="active" @endif>
					<a href="{{ url('/members') }}">
						<i class="fa fa-user-secret"></i>
						<span class="title">Members</span>
					</a>
				</li>
			@endpermission

			@permission('lotin-list')
				<li @if(Request::segment(1) == 'lotins') class="active" @endif>
					<a href="{{ url('/lotins') }}">
						<i class="fa fa-truck"></i>
						<span class="title">Lot-in</span>
					</a>
				</li>
			@endpermission

			@permission('tracking-list')
				<li @if(Request::segment(1) == 'trackings') class="active" @endif>
					<a href="{{ url('/trackings') }}">
						<i class="fa fa-map"></i>
						<span class="title">Tracking</span>
					</a>
				</li>
			@endpermission

			@permission('lotbalance-list')
				<li @if(Request::segment(1) == 'lotbalances') class="active" @endif>
					<a href="{{ url('/lotbalances') }}">
						<i class="fa fa-shopping-cart"></i>
						<span class="title">Lot Balance</span>
					</a>
				</li>
			@endpermission

			@permission('outgoing-list')
				<li @if(Request::segment(1) == 'outgoings') class="active" @endif>
					<a href="{{ url('/outgoings') }}">
						<i class="fa fa-shopping-cart"></i>
						<span class="title">Outgoing</span>
					</a>
				</li>
			@endpermission

			@permission('incoming-list')
				<li @if(Request::segment(1) == 'incomings') class="active" @endif>
					<a href="{{ url('/incomings') }}">
						<i class="fa fa-truck"></i>
						<span class="title">Incoming</span>
					</a>
				</li>
			@endpermission

			@permission('collection-list')
				<li @if(Request::segment(1) == 'collections') class="active" @endif>
					<a href="{{ url('/collections') }}">
						<i class="fa fa-database"></i>
						<span class="title">Collections</span>
					</a>

					<ul>
						<li @if(Request::segment(1) == 'collections') class="active" @endif>
							<a href="{{ url('/collections/ready-collect') }}">
								<i class="entypo-archive"></i>
								<span class="title">Ready To Collect</span>
							</a>
						</li>

						<li @if(Request::segment(1) == 'collections') class="active" @endif>
							<a href="{{ url('/collections/return') }}">
								<i class="entypo-database"></i>
								<span class="title">Return To Head Office</span>
							</a>
						</li>
					</ul>
				</li>
			@endpermission

			{{-- @permission('message-list')
				<li @if(Request::segment(1) == 'messages') class="active" @endif>
					<a href="{{ url('/messages') }}">
						<i class="entypo-mail"></i>
						<span class="title">Messages</span>
						<span class="badge badge-secondary">8</span>
					</a>
					<ul>
						<li>
							<a href="mailbox.html">
								<i class="entypo-inbox"></i>
								<span class="title">Inbox</span>
							</a>
						</li>
						<li>
							<a href="mailbox-compose.html">
								<i class="entypo-pencil"></i>
								<span class="title">Compose Message</span>
							</a>
						</li>
						<li>
							<a href="mailbox-message.html">
								<i class="entypo-attach"></i>
								<span class="title">View Message</span>
							</a>
						</li>
					</ul>
				</li>
			@endpermission --}}

			@permission('report-list')
				<li @if(Request::segment(1) == 'reports') class="active" @endif>
					<a href="{{ url('/reports') }}">
						<i class="entypo-chart-bar"></i>
						<span class="title">Reports</span>
					</a>

					<ul>
						<li @if(Request::segment(1) == 'reports') class="active" @endif>
							<a href="{{ url('/reports/sales') }}">
								<i class="entypo-chart-pie"></i>
								<span class="title">Daily Sales Report</span>
							</a>
						</li>

						<li @if(Request::segment(1) == 'reports') class="active" @endif>
							<a href="{{ url('/reports/bytrips') }}">
								<i class="entypo-chart-line"></i>
								<span class="title">Sales Report By Trip</span>
							</a>
						</li>
					</ul>
				</li>
			@endpermission
		</ul>

	</div>

</div>
